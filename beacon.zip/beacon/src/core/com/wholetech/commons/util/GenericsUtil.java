package com.wholetech.commons.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 泛型工具类。
 * 可以获取指定类中所具体化的泛型。
 */
public class GenericsUtil {

	private static final Logger log = LoggerFactory.getLogger(GenericsUtil.class);

	private GenericsUtil() {

	}

	/**
	 * 通过反射,获得定义Class时声明的父类的范型参数的类型. 如public BookManager extends GenricManager<Book>
	 *
	 * @param clazz
	 *            The class to introspect
	 * @return the first generic declaration, or <code>Object.class</code> if
	 *         cannot be determined
	 */
	public static Class getSuperClassGenricType(final Class clazz) {

		return GenericsUtil.getSuperClassGenricType(clazz, 0);
	}

	/**
	 * 通过反射,获得定义Class时声明的父类的范型参数的类型. 如public BookManager extends GenricManager<Book>
	 *
	 * @param clazz
	 *            clazz The class to introspect
	 * @param index
	 *            the Index of the generic ddeclaration,start from 0.
	 * @return the index generic declaration, or <code>Object.class</code> if
	 *         cannot be determined
	 */
	public static Class getSuperClassGenricType(final Class clazz, final int index) {

		final Type genType = clazz.getGenericSuperclass();

		if (!(genType instanceof ParameterizedType)) {
			GenericsUtil.log.warn(clazz.getSimpleName()
					+ "'s superclass not ParameterizedType");
			return Object.class;
		}

		final Type[] params = ((ParameterizedType) genType).getActualTypeArguments();

		if (index >= params.length || index < 0) {
			GenericsUtil.log.warn("Index: " + index + ", Size of " + clazz.getSimpleName()
					+ "'s Parameterized Type: " + params.length);
			return Object.class;
		}
		if (!(params[index] instanceof Class)) {
			GenericsUtil.log.warn(clazz.getSimpleName()
					+ " not set the actual class on superclass generic parameter");
			return Object.class;
		}
		return (Class) params[index];
	}

	/**
	 * 获取一个类中声明泛型的类。如果有多个泛型，则返回声明的第一个。
	 *
	 * @param clazz
	 *            要从中获取泛型的类。
	 * @return 参数clazz中声明的第一个泛型。
	 */
	public static Class getGenericClass(final Class clazz) {

		return GenericsUtil.getGenericClass(clazz, 0);
	}

	/**
	 * 获取一个类中声明泛型的类。参数index指定要第几个声明泛型的类。
	 *
	 * @param clazz
	 *            从中获取泛型的类。
	 * @param index
	 *            第几个泛型。
	 */
	public static Class getGenericClass(final Class clazz, final int index) {

		final Type genType = clazz.getGenericSuperclass();

		if (genType instanceof ParameterizedType) {
			final Type[] params = ((ParameterizedType) genType)
					.getActualTypeArguments();

			if ((params != null) && (params.length >= (index - 1))) {
				return (Class) params[index];
			}
		}
		return null;
	}
}
