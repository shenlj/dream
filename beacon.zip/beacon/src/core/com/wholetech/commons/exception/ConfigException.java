package com.wholetech.commons.exception;

public class ConfigException extends RuntimeException {

	public ConfigException() {

	}

	public ConfigException(final String msg) {

		super(msg);
	}

}
