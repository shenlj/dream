package com.wholetech.commons;

import javax.servlet.http.HttpServletRequest;

import com.wholetech.commons.util.SessionInfoHolder;

public class SessionInfoHolderImp implements SessionInfoHolder {

	@Override
	public String getEmail(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLoginIP(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLoginId(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLoginName(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLoginTime(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getMobilePhone(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getOrgCode(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getOrgName(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getOrgPath(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPasswd(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUserId(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isLogined(final HttpServletRequest request) {

		// TODO Auto-generated method stub
		return false;
	}

}
