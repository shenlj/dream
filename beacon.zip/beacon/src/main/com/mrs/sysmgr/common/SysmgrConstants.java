package com.mrs.sysmgr.common;

public class SysmgrConstants extends com.wholetech.commons.Constants {

	/** 男女 **/
	public static final String SEX_M = "男";
	public static final String SEX_F = "女";

	/** 是否代码 **/
	public static final String SFDM_Y = "1";// 是
	public static final String SFDM_N = "0";// 否
}
