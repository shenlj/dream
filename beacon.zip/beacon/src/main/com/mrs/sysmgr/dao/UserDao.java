package com.mrs.sysmgr.dao;

import com.mrs.sysmgr.entity.User;
import com.wholetech.commons.dao.BaseDao;

public interface UserDao extends BaseDao<User> {
}
