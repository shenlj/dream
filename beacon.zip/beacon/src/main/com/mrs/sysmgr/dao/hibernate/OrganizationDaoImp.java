package com.mrs.sysmgr.dao.hibernate;

import com.mrs.sysmgr.dao.OrganizationDao;
import com.mrs.sysmgr.entity.Organization;
import com.wholetech.commons.dao.BaseDaoImp;

public class OrganizationDaoImp extends BaseDaoImp<Organization> implements OrganizationDao {

}
