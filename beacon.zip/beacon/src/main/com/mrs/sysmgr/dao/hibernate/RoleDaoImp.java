package com.mrs.sysmgr.dao.hibernate;

import com.mrs.sysmgr.dao.RoleDao;
import com.mrs.sysmgr.entity.Role;
import com.wholetech.commons.dao.BaseDaoImp;

public class RoleDaoImp extends BaseDaoImp<Role> implements RoleDao {

}
