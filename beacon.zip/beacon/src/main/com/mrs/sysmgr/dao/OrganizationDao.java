package com.mrs.sysmgr.dao;

import com.mrs.sysmgr.entity.Organization;
import com.wholetech.commons.dao.BaseDao;

/**
 * 描述：组织机构Dao接口
 */
public interface OrganizationDao extends BaseDao<Organization> {
}
