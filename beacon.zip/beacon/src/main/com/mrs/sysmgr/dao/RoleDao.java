package com.mrs.sysmgr.dao;

import com.mrs.sysmgr.entity.Role;
import com.wholetech.commons.dao.BaseDao;

public interface RoleDao extends BaseDao<Role> {

}
