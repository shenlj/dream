package com.mrs.sysmgr.dao.hibernate;

import com.mrs.sysmgr.dao.UserDao;
import com.mrs.sysmgr.entity.User;
import com.wholetech.commons.dao.BaseDaoImp;

public class UserDaoImp extends BaseDaoImp<User> implements UserDao {

}
