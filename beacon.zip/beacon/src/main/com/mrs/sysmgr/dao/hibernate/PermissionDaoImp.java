package com.mrs.sysmgr.dao.hibernate;

import com.mrs.sysmgr.dao.PermissionDao;
import com.mrs.sysmgr.entity.Permission;
import com.wholetech.commons.dao.BaseDaoImp;

public class PermissionDaoImp extends BaseDaoImp<Permission> implements PermissionDao {

}
