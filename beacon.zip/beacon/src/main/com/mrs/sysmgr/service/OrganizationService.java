package com.mrs.sysmgr.service;

import com.mrs.sysmgr.entity.Organization;
import com.wholetech.commons.service.BaseService;

public interface OrganizationService extends BaseService<Organization> {

}
