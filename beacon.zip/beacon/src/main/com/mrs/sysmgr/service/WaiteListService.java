package com.mrs.sysmgr.service;

import java.util.List;
import java.util.Map;

import com.wholetech.commons.service.BaseService;

public interface WaiteListService extends BaseService {

	public List<Map> getWaiteList();
}
