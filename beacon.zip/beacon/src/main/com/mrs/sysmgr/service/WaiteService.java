package com.mrs.sysmgr.service;

import com.mrs.sysmgr.entity.User;

public interface WaiteService {

	public int getWaiteNum(User user);
}
